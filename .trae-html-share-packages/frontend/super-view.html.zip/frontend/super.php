<?php
require_once dirname(__DIR__) . '/api/config.php';
require_once dirname(__DIR__) . '/api/auth_lib.php';

$database = new Database();
$db = $database->getConnection();
$token = getRequestToken();

if (!$token) {
    header('Location: super-login.html', true, 302);
    exit;
}

$stmt = $db->prepare("SELECT role, user_id FROM sessions WHERE token_hash = ? AND expires_at > NOW() LIMIT 1");
$stmt->execute([hash('sha256', $token)]);
$session = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$session || $session['role'] !== 'admin') {
    header('Location: super-login.html?denied=1', true, 302);
    exit;
}

$stmt = $db->prepare("SELECT a.id, a.name, a.email, a.privilege, a.is_active, a.organization_id
    FROM admins a WHERE a.id = ? AND COALESCE(a.is_active, 1) = 1 LIMIT 1");
$stmt->execute([$session['user_id']]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin || ($admin['privilege'] ?? '') !== 'super_admin') {
    header('Location: admin.php', true, 302);
    exit;
}

$user = publicAdminUser($admin);

header('Content-Type: text/html; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
serveHtmlWithBoot(__DIR__ . '/super-view.html', [
    'role' => 'admin',
    'privilege' => $user['privilege'],
    'user' => $user
]);
